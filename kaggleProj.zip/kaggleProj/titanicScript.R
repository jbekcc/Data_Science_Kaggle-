mydata = read.csv("titanic.csv") 
gender <- mydata[c("Survived", "Pclass", "Sex")]
genderM <- subset(gender, Sex = "male")
genderF <- subset(genderM, Survived = 1)
count <- count(genderF, 'Pclass')
regLine <- lm(freq~Pclass, count)
abline(regLine, lw=3, col='red')